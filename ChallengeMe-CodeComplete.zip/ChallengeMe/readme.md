# A few notes

* Don't update the `.classpath` `.project` `.settings` files in the future. The only reason they are here is for your convenience to build your project for the first time.
* *DO NOT WRITE YOUR CODE BEFORE PULL FROM ORIGIN!!* or you have solve merge conflicts.
