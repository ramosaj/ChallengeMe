package db;

public class CompletedChallenge {
	
	public static final String TBL_NAME = "UserCompleted";

}
