package db;

public class InterestedChallenge {

	public static final String TBL_NAME = "InterestedChallengeJunction";
	
}
